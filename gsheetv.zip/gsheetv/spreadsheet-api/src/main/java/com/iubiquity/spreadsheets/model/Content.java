package com.iubiquity.spreadsheets.model;

import com.google.api.client.util.Key;

public class Content {

  @Key("@src")
  public String src;

}
